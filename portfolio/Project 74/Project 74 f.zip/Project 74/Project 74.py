import matplotlib.pyplot as plt
import os.path
import numpy as np
import csv

'''
Ryan Le and Astraea Shao
Project 74: Race and Violent Crime
Data used in our bar graphs was provided by the FBI website.
Links at https://ucr.fbi.gov/crime-in-the-u.s/2015/crime-in-the-u.s.-2015 and https://ucr.fbi.gov/crime-in-the-u.s/2014/crime-in-the-u.s.-2014
'''

#Get current working directory
directory = os.path.dirname(os.path.abspath(__file__))
# Open the file
filename = os.path.join(directory, 'EDITED Table_43A_Arrests_by_Race_and_Ethnicity_2015'+'.csv')
filename1 = os.path.join(directory, 'EDITED Table_43A_Arrests_by_Race_2014'+'.csv')
filename2 = os.path.join(directory, 'white1.csv')
filename3 = os.path.join(directory, 'black1.csv')
datafile = open(filename,'r') #'r' means read only
datafile1 = open(filename1,'r')
datumfile1 = open(filename2, 'r')
datumfile2 = open(filename3, 'r')
#Reads each line and stores it in a variable.
data = datafile.readlines()
data1 = datafile1.readlines()
datafile1= csv.reader(datumfile1)
datafile2= csv.reader(datumfile2)

#Skips line in data
next(datafile2)

#Create lists to store data
races = []
numbers_in_2015 = []
numbers_in_2014 = []
white = []
black = []
labels = []

for line in data:
    race, number = line.split(",")
    races.append(race)
    numbers_in_2015.append(number)
    
for line in data1:
    race,number = line.split(",")
    numbers_in_2014.append(number)
    
for line in datafile2:
    the_label = line[0]
    percentage = line[3]
    # Adds the number of people in the house to a list
    labels.append(the_label)
    black.append(percentage)

#Skip line
next(datafile1)

for line in datafile1:
    percentagew = line[3]   
    white.append(percentagew)
    

#Removes total and its number, since we don't need to show it in our visualization       
races.remove('TOTAL')
numbers_in_2015.remove(' 8248709\n')
numbers_in_2014.remove(' 8730665\n')

number_of_races = 5 #Number of all races listed in data
ind = np.arange(number_of_races) #x-location for each bar
width=0.25 #Sets width of each bar

#Creates a bar graph 
plt.figure(1) #First graph
legend1 = plt.bar(range(len(races)), numbers_in_2015, align='center',color='blue', width=width)
legend2 = plt.bar(ind+width, numbers_in_2014, align='center',color='red',width=width)
plt.xticks(range(len(races)), races, fontsize=10)
plt.xticks(ind + width / 2) 
plt.ylabel("Number of crimes committed")
plt.suptitle("Crimes committed in 2015 (Blue) and 2014 (Red)")
plt.legend((legend1[0], legend2[1]),('2015','2014'))

plt.figure(2) #Second graph
blackbar=plt.bar(range(len(labels)), black,  0.9, color='#461858', bottom=white)
whitebar=plt.bar(range(len(labels)), white,  0.9, color='#16E82C')

plt.title('Arrest rate on percentage of population')
plt.xticks(range(len(labels)), labels, rotation='vertical', fontsize=11)
plt.xlabel('Different crimes')
plt.ylabel('Percentage of race that commit crime')
plt.legend((blackbar[0], whitebar[0]),('African American','White American'))

plt.show()